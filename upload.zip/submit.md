- label：用户点击其内的文本时，鼠标将自动聚焦到文本对应的框。

- form：表单。

- button：按钮。

- img：图片。

- input：表单输入。

- div、span：块。

- header：简介。

- footer：页脚。

- section：定义文档中的节，使其功能分块。
